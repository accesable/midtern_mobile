package com.mvm.lab05_ex2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<String> items;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initSampleData();
        recyclerView = findViewById(R.id.recyclerView);
    }

    private void initSampleData() {
        items = new ArrayList<>();
        for (int i = 1; i <= 30; i++) {
            items.add("Student " + i);
        }
    }
}