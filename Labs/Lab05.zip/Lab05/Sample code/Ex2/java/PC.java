package com.mvm.lab05_ex6;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

public class PC {

    private String label;
    private boolean on;

    public PC(int id) {
        this.label = "PC " + String.format("%02d", id);
        this.on = false;
    }

    public PC(String label, boolean on) {
        this.label = label;
        this.on = on;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public boolean isOn() {
        return on;
    }

    public void setOn(boolean on) {
        this.on = on;
    }

    public static List<PC> generate(int numOfPc) {
        if (numOfPc <= 0 || numOfPc > 200) {
            throw new InvalidParameterException("Num of PC must in [1,200]");
        }
        List<PC> list = new ArrayList<>();
        for (int i = 1; i <= numOfPc; i++) {
            list.add(new PC(i));
        }
        return list;
    }
}
